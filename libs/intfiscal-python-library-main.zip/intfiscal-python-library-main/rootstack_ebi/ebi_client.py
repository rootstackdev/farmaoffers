from zeep import Client
from zeep.transports import Transport


class EbiClient:
    def __init__(self, wsdl, token_entity, password_entity):
        self.password_entity = password_entity
        self.token_entity = token_entity
        self.wsdl = wsdl
        transport = Transport()
        self.client = Client(wsdl, transport=transport)

    def enviar(self, _document):
        _data = _document.format_dict_data()
        _vals = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'documento': _document.format_dict_data()
        }
        return self.client.service.Enviar(**_vals)

    def consultarRucDV(self, _tipoRuc, _ruc):
        consultarRucDVRequest = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'tipoRuc': _tipoRuc,
            'ruc': _ruc
        }
        return self.client.service.ConsultarRucDV(consultarRucDVRequest)

    def consultarEstadoDocumento(self, _sucursal, _numero_documento_fiscal, _punto_documento_fiscal, _tipo_documento,
                                 _tipo_emision):
        _params = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'datosDocumento': {
                'codigoSucursalEmisor': _sucursal,
                'numeroDocumentoFiscal': _numero_documento_fiscal,
                'puntoFacturacionFiscal': _punto_documento_fiscal,
                'tipoDocumento': _tipo_documento,
                'tipoEmision': _tipo_emision
            }
        }
        return self.client.service.EstadoDocumento(**_params)

    def descargaXml(self, _codigo_sucursal_emisor, _numero_documento_fiscal, _punto_facturacion_fiscal, _tipo_Documento,
                    _tipo_emision):
        _params = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'datosDocumento': {
                'codigoSucursalEmisor': _codigo_sucursal_emisor,
                'numeroDocumentoFiscal': _numero_documento_fiscal,
                'puntoFacturacionFiscal': _punto_facturacion_fiscal,
                'tipoDocumento': _tipo_Documento,
                'tipoEmision': _tipo_emision
            }
        }
        return self.client.service.DescargaXML(**_params)

    def descargaPdf(self, _codigo_sucursal_emisor, _numero_documento_fiscal, _punto_facturacion_fiscal, _tipo_Documento,
                    _tipo_emision):
        _params = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'datosDocumento': {
                'codigoSucursalEmisor': _codigo_sucursal_emisor,
                'numeroDocumentoFiscal': _numero_documento_fiscal,
                'puntoFacturacionFiscal': _punto_facturacion_fiscal,
                'tipoDocumento': _tipo_Documento,
                'tipoEmision': _tipo_emision
            }
        }
        return self.client.service.DescargaPDF(**_params)

    def envioCorreo(self, _correo, _codigo_sucursal_emisor, _numero_documento_fiscal, _punto_facturacion_fiscal, _tipo_Documento,
                    _tipo_emision):
        _params = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'correo': _correo,
            'datosDocumento': {
                'codigoSucursalEmisor': _codigo_sucursal_emisor,
                'numeroDocumentoFiscal': _numero_documento_fiscal,
                'puntoFacturacionFiscal': _punto_facturacion_fiscal,
                'tipoDocumento': _tipo_Documento,
                'tipoEmision': _tipo_emision
            }
        }
        return self.client.service.EnvioCorreo(**_params)

    def anulacion(self, _motivo, _codigo_sucursal_emisor, _numero_documento_fiscal, _punto_facturacion_fiscal,
                  _tipo_Documento, _tipo_emision):
        _params = {
            'tokenEmpresa': self.token_entity,
            'tokenPassword': self.password_entity,
            'motivoAnulacion': _motivo,
            'datosDocumento': {
                'codigoSucursalEmisor': _codigo_sucursal_emisor,
                'numeroDocumentoFiscal': _numero_documento_fiscal,
                'puntoFacturacionFiscal': _punto_facturacion_fiscal,
                'tipoDocumento': _tipo_Documento,
                'tipoEmision': _tipo_emision
            }
        }
        return self.client.service.AnulacionDocumento(**_params)
