ELECTRONIC_DOCUMENT_DEFAULT = {
    'codigoSucursalEmisor': '',
    'tipoSucursal': '',
    'datosTransaccion': {},
    'listaItems': [],
    'totalesSubTotales': {},
}

CLIENT_DEFAULT = {
    'tipoClienteFE': None,
    'tipoContribuyente': None,
    'numeroRUC': None,
    'digitoVerificadorRUC': None,
    'razonSocial': None,
    'direccion': None,
    'codigoUbicacion': None,
    'corregimiento': None,
    'distrito': None,
    'provincia': None,
    'telefono1': None,
    'telefono2': None,
    'telefono3': None,
    'correoElectronico1': None,
    'pais': None,
    'paisOtro': None,
    'paisExtranjero': None
}

TRANSACTION_DATA_DEFAULT = {
    'tipoEmision': None,
    'tipoDocumento': None,
    'numeroDocumentoFiscal': None,
    'puntoFacturacionFiscal': None,
    'fechaEmision': None,
    'naturalezaOperacion': None,
    'tipoOperacion': None,
    'destinoOperacion': None,
    'formatoCAFE': None,
    'entregaCAFE': None,
    'envioContenedor': None,
    'procesoGeneracion': None,
    'tipoVenta': None,
    'informacionInteres': None,
    'cliente': None
}

TRANSACTION_ITEM_DEFAULT = {
    'descripcion': None,
    'codigo': None,
    'unidadMedida': None,
    'cantidad': None,
    'fechaFabricacion': None,
    'unidadMedidaCPBS': None,
    'precioUnitario': None,
    'precioUnitarioDescuento': None,
    'precioAcarreo': None,
    'precioSeguro': None,
    'precioItem': None,
    'valorTotal': None,
    'codigoGTIN': None,
    'cantGTINCom': None,
    'codigoGTINInv': None,
    'cantGTINComInv': None,
    'tasaITBMS': None,
    'valorITBMS': None,
    'tasaISC': None,
    'valorISC': None,
    'codigoCPBS': None,
}


def convert_to_dict(obj):
    if not hasattr(obj, "__dict__"):
        return obj
    result = {}
    for key, val in obj.__dict__.items():
        if key.startswith("_"):
            continue
        element = {}
        _items = []
        if isinstance(val, list):
            class_name = type(val[0]).__name__
            class_name = class_name[0].lower() + class_name[1:]
            for item in val:
                _items.append(convert_to_dict(item))
            element[class_name] = _items
        else:
            element = convert_to_dict(val)
        if element:
            result[key] = element
    return result


class ElectronicDocument(object):
    codigoSucursalEmisor = None
    tipoSucursal = None
    datosTransaccion = None
    listaItems = []
    totalesSubTotales = None

    def __init__(self, _data=None):
        if _data is None:
            _data = {}
        values = {**_data, **ELECTRONIC_DOCUMENT_DEFAULT}
        for key, val in values.items():
            setattr(self, key, val)

    def format_dict_data(self):
        return convert_to_dict(self)


class Client(object):
    tipoClienteFE = None
    tipoContribuyente = None
    numeroRUC = None
    digitoVerificadorRUC = None
    razonSocial = None
    direccion = None
    codigoUbicacion = None
    corregimiento = None
    distrito = None
    provincia = None
    telefono1 = None
    telefono2 = None
    telefono3 = None
    correoElectronico1 = None
    pais = None
    paisOtro = None
    nroIdentificacionExtranjero = None
    tipoIdentificacion = None
    paisExtranjero = None

    def __init__(self, _data=None):
        if _data is None:
            _data = {}
        values = {**_data, **CLIENT_DEFAULT}
        for key, val in values.items():
            setattr(self, key, val)


class TransactionData:
    tipoEmision = None
    fechaInicioContingencia = None
    motivoContingencia = None
    tipoDocumento = None
    numeroDocumentoFiscal = None
    puntoFacturacionFiscal = None
    fechaEmision = None
    naturalezaOperacion = None
    tipoOperacion = None
    destinoOperacion = None
    formatoCAFE = None
    entregaCAFE = None
    envioContenedor = None
    procesoGeneracion = None
    tipoVenta = None
    informacionInteres = None
    cliente = None
    listaDocsFiscalReferenciados = None

    def __init__(self, _data=None):
        if _data is None:
            _data = {}
        values = {**_data, **TRANSACTION_DATA_DEFAULT}
        for key, val in values.items():
            setattr(self, key, val)


class Item:
    descripcion = None
    codigo = None
    unidadMedida = None
    cantidad = None
    fechaFabricacion = None
    unidadMedidaCPBS = None
    precioUnitario = None
    precioUnitarioDescuento = None
    precioAcarreo = None
    precioSeguro = None
    precioItem = None
    valorTotal = None
    codigoGTIN = None
    cantGTINCom = None
    codigoGTINInv = None
    cantGTINComInv = None
    tasaITBMS = None
    valorITBMS = None
    tasaISC = None
    valorISC = None
    codigoCPBS = None

    def __init__(self, _data=None):
        if _data is None:
            _data = {}
        values = {**_data, **TRANSACTION_ITEM_DEFAULT}
        for key, val in values.items():
            setattr(self, key, val)


class Totals:
    totalPrecioNeto = None
    totalITBMS = None
    totalISC = None
    totalMontoGravado = None
    totalDescuento = None
    totalAcarreoCobrado = None
    valorSeguroCobrado = None
    totalFactura = None
    totalValorRecibido = None
    vuelto = None
    tiempoPago = None
    nroItems = None
    totalTodosItems = None
    listaFormaPago = []
    listaDescBonificacion = []


class FormaPago:
    formaPagoFact = None
    valorCuotaPagada = None
    descFormaPago = None


class DocFiscalReferenciado:
    fechaEmisionDocFiscalReferenciado = None
    cufeFEReferenciada = None
    nroFacturaPapel = None
    nroFacturaIF = None


class DatosFacturaExportacion:
    condicionesEntrega = None
    monedaOperExportacion = None
    monedaOperExportacionNonDef = None
    tipoDeCambio = None
    montoMonedaExtranjera = None
    puertoEmbarque = None

class DescuentoBonificacion:
    descDescuento=None
    montoDescuento=None