TIPO_EMISION = {
    "01": "Autorización de Uso Previa, operación normal",
    "02": "Autorización de Uso Previa, operación en contingencia",
    "03": "Autorización de Uso Posterior, operación normal",
    "04": "Autorización de Uso posterior, operación en contingencia"
}

TIPO_DOCUMENTO = {
    "01": "Factura de operación interna",
    "02": "Factura de importación",
    "03": "Factura de exportación",
    "04": "Nota de Crédito referente a una FE",
    "05": "Nota de Débito referente a una FE",
    "06": "Nota de Crédito genérica",
    "07": "Nota de Débito genérica",
    "08": "Factura de Zona Franca",
    "09": "Reembolso",
}

NATURALEZA_OPERACION = {
    "01": "Venta",
    "02": "Exportación",
    "10": "Transferencia",
    "11": "Devolución",
    "12": "Consignación",
    "13": "Remesa",
    "14": "Entrega gratuita",
    "20": "Compra",
    "21": "Importación",
}

TIPO_OPERACION = {
    "1": "Salida o venta",
    "2": "Entrada o compra",
}

DESTINO_OPERACION = {
    "1": "Panamá",
    "2": "Extranjero",
}

FORMATO_CAFE = {
    "1": "Sin generación de CAFE",
    "2": "Cinta de papel",
    "3": "Papel formato carta",
}

ENTREGA_CAFE = {
    "1": "Sin generación de CAFE",
    "2": "CAFE entregado para el receptor en papel",
    "3": "CAFE enviado para el receptor en formato electrónico",
}

ENVIO_CONTENEDOR = {
    "1": "Normal",
    "2": "El receptor exceptúa al emisor de la obligatoriedad de envío del contenedor",
}

TIPO_VENTA = {
    "1": "Venta de Giro del negocio",
    "2": "Venta Activo Fijo",
    "3": "Venta de Bienes Raíces",
    "4": "Prestación de Servicio",
}

TIPO_SUCURSAL = {
    "1": "Mayor cantidad de Operaciones venta al detal (retail)",
    "2": "Mayor cantidad de Operaciones venta al por mayor"
}

# DATOS PARA EL CLIENTE

TIPO_CLIENTE_FE = {
    "01": "Contribuyente",
    "02": "Consumidor final",
    "03": "Gobierno",
    "04": "Extranjero"
}

TIPO_CONTRIBUYENTE = {
    "1": "Natural",
    "2": "Jurídico"
}

TIPO_IDENTIFICACION = {
    "01": "Pasaporte",
    "02": "Numero Tributario",
    "99": "Otro"
}

TASA_ITBMS = {
    "00": 0,
    "01": 7,
    "02": 10,
    "03": 15
}
