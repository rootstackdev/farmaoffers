# rootstack_ebi

python library that allows connecting to the webservice of the electronic invoicing provider EBI-PAC for sending electronic documents